# GECS Changelog

## [9.3.4] - 2026-09-18 - Network spawn signals

### Fixed

- `NetworkSync.entity_spawned` and `NetworkSync.local_player_spawned` now fire.
  Both signals were declared, documented, and used by the network example, but the
  emit calls were lost in the Network v2 rewrite, so connecting to them did nothing.
  Clients get them after a spawn payload or late-join world state is applied. The
  host gets them right before it broadcasts the spawn, so the same
  `network_sync.entity_spawned.connect(...)` code works on every peer.
  `local_player_spawned` fires only for player entities owned by the local peer.
  Updates to an entity that already exists, stale-session payloads, and spawns
  cancelled in the same frame do not emit. Thanks to raydenuni for the report.
- Corrected the `Entity.relationships_batch_removed` doc comment. The signal has not
  been emitted since v8.0.0; connect to `relationship_removed` instead.

### Validation

- New `test_network_sync_signals.gd` drives a real `NetworkSync` as both client and
  host, and adds a source scan that fails when any signal under `addons/gecs` is
  declared but never emitted.

## [9.3.3] - 2026-09-11 - Explorer polling and breakpoint controls

### Fixed

- Open Explorer and detached windows keep polling their displayed content when
  focus returns to the game. Polling runs independently of the debugger dock;
  hidden tabs and closed views stop automatic data reads.
- Detached entity windows now initialize correctly as independent native windows.
- Breakpoint pauses retain and display the triggering system and reason across
  state refreshes. The pause notice explains repeated breaks and offers
  **Disable this breakpoint**, followed by **Resume** to continue processing.
- Explorer exposes breakpoint management beside the stepping controls, including
  enable/disable, **Remove selected**, and **Clear all**. System rows show their
  breakpoint status and offer enable, disable, and remove actions in the context menu.

### Validation

- All 656 debugger and core tests passed. Native-window focus/polling checks and
  breakpoint UI layout checks also passed.

## [9.3.0] - 2026-09-11 - Explorer, step debugger, QueryBuilder.from(), relationship cleanup fixes

### Added

- **Explicit queries over entity arrays with `QueryBuilder.from(entities)`.**
  Chain normal filters and call `execute()` or `execute_one()` on a fresh snapshot
  of a retained array. Supports live bucket edits, skips stale references, and
  accepts entities outside the query's world. System/observer declarations and
  direct archetype iteration reject this source. Thanks to **TheWightOne** for
  the idea. See the query guide in `addons/gecs/docs/CORE_CONCEPTS.md`.

- **Entity lifecycle benchmarks and batch correctness coverage.** Comparable loop,
  batch and command-buffer timings separate allocation, registration, removal and
  elapsed time through deferred deletion. Includes sustained churn with residents,
  pool activation and relationship-scaling probes. Repeated results retain raw
  samples, p95 and execution-mode metadata; the performance report adds a Lifecycle
  category and run-label filter. See `addons/gecs/docs/ENTITY_LIFECYCLE_PERFORMANCE.md`.

- **GECS Explorer companion window.** A floating workspace that opens beside the
  running game as soon as a debugger session starts, so the game stays visible
  (or move it to another monitor). Closing it only hides it: entity tabs, drafts,
  watches and session history survive, and **Show Explorer** in the debugger
  brings it back. It includes:
  - **World overview**: entity, component, relationship, system, observer,
    archetype and cached-query counts, with selectable population and
    system-time charts. Sampling only runs while the tab is visible.
  - **Entity tabs**: components, relationships in both directions (incoming
    links show which entity owns the pair), up to 16 live property charts, a
    relationship map, and staged edits sent to the running game with
    **Apply to game** or **Apply & Step**.
  - **Queries**: an All / Any / None filter builder with property comparisons
    that shows the generated QueryBuilder code, plus saved queries and history.
  - **Scratchpad**, **Watches** (entity subscriptions and live query
    membership), **Systems** timings, and **Changes** (before/after capture
    comparison plus live activity).
  - **ECS snapshot files**: while paused, export component values to
    `.gecs-state.json` and restore them onto matching entities after a preview.
    This is a debugging aid, not a save system; it does not recreate entities
    or modify relationships.

  See `addons/gecs/docs/DEBUG_VIEWER.md`.

- **Step debugger (forward-only).** Pause the ECS and run it one frame, group,
  system, archetype or entity at a time while the game keeps calling
  `ECS.process()`: paused calls return immediately unless a step is pending for
  that group, so group order and delta stay exactly what the game produces.
  Every step reports a mutation log (component add/remove, emitted property
  changes, relationships, entity add/remove/enable, custom events) attributed
  to the system, CommandBuffer flush or observer that caused it, plus a diff
  sweep that catches writes made without an emitting setter. Breakpoints pause
  a live world before a system runs, or right after the system that added or
  removed a component type or touched an entity. `Kind.ENTITY` takes a "step
  set": each listed entity runs as its own `process()` call. Headless API on
  `World`: `debug_pause()`, `debug_resume()`, `debug_step(kind, count)`,
  `debug_set_step_entities()`, `debug_add_breakpoint()` (and remove / enable /
  clear), `debug_set_sweep()`, `debug_graph_watch()`, `debug_step_state()`;
  signals `step_completed(kind, info)` and `step_break_hit(id, info)`. New
  classes `GECSStepper`, `GECSDiffSweep`, `GECSGraphState` under
  `addons/gecs/debug/step/`; `System` gained a stepper-only resumable
  execution path (`_step_begin` / `_step_next_batch` / `_step_run` /
  `_step_end`) that mirrors `_handle` batch by batch and leaves the hot path
  untouched. While no stepper is active the cost is one bool per mutation
  funnel and per system per frame. Docs: `addons/gecs/docs/STEP_DEBUGGER.md`.
- **Entity relationship graph feed.** `GECSGraphState.build(world, entities,
  depth)` returns the watched entities (components inside), inbound and
  outbound relationships as edges, and non-entity targets (archetype scripts,
  component instances, wildcard) as nodes. The stepper keeps any number of
  graphs keyed by id (`debug_graph_watch(entities, depth, graph_id)`,
  `debug_graph_close(id)`, `debug_graph_state(id)`) and pushes every open one to
  the editor after each step.
- **Debugger messages** `gecs:step_state`, `gecs:step_log`, `gecs:graph_state`
  and editor commands `step_pause`, `step_resume`, `step`, `step_set_entities`,
  `step_set_sweep`, `step_pull_state`, `breakpoint_add/remove/set_enabled/clear`,
  `graph_watch [id, ids, depth]`, `graph_pull [id]`, `graph_close [id]`.
  `GECSEditorDebuggerMessages.serialize_relationship()`
  is now shared by the lifecycle message and the graph feed.
- **Debugger tab: step debugger pane + graph windows.** A compact pane next to
  the entity / system trees holds the transport (Pause, Resume, Step Frame /
  Group / System / Archetype / Entity with a count), the step set, a status
  line, and a Step log / Breakpoints tab pair (the log has one row per step,
  break or external bucket, expanding to the journaled ops with their cause).
  *Open graph* on an entity row opens a floating window with a GraphEdit of the
  watched entities, components inside the nodes and relationships as
  connections; any number of graph windows can be open at once, each with its
  own watch set, depth and "Show live" toggle (poll-rate refresh while live,
  every step while paused). The systems tree gained a Step cursor column and a
  BP checkbox column; entity rows are multi-selectable and their context menu
  offers Add to step set, Break when touched and Open graph; component rows
  offer Break when added / removed; system rows offer Break before run. Rows
  touched by the last step are tinted. The Pop Out window now sizes itself to
  the tab's content. New scripts `gecs_editor_step_panel.gd`,
  `gecs_editor_graph_panel.gd`, `gecs_editor_graph_window.gd`; suite
  `tests/debug/test_editor_debugger_tab_step.gd`.
- Test suites under `tests/debug/`: `test_stepper_pause`, `test_stepper_unit_steps`,
  `test_stepper_frame_step`, `test_stepper_journal_and_sweep`,
  `test_stepper_breakpoints`, `test_stepper_graph_and_commands`.

### Fixed

- **Relationship read paths desynced the archetype index.** `Entity.get_relationship()`
  and `get_relationships()` drop relationships whose target was freed outside
  `World.remove_entity()`, but did so without telling the World. The entity's
  archetype kept the stale pair key, so `with_relationship()` queries and Systems
  kept matching an entity whose relationship was already gone, and neither
  `World.relationship_removed` nor `on_relationship_removed()` observers fired.
  Both read paths now notify the World in the same order as `remove_relationship()`,
  and `World._on_entity_relationship_removed()` recomputes the archetype when the
  target is freed (there is no slot key to walk an edge with in that case), which
  also fixes `remove_relationship(rel)` by instance on a dangling target. Regression suite:
  `tests/core/test_relationship_read_path_cleanup.gd`.
- **Batch-added components never emitted change events.** `Entity.add_components()`
  stored components without setting `component.parent` or connecting
  `property_changed`, so writes through emitting setters on batch-added components
  were invisible to `on_changed()` observers, `.changed()` change detection and
  property-query monitors. `add_components()` now wires both, matching
  `add_component()`. Regression suite: `tests/core/test_add_components_signals.gd`.
- **Archetype swap-remove errored on a freed tail row.** `Archetype.remove_entity()`
  moves the last row into the vacated slot; when that row belonged to an entity
  freed outside `World.remove_entity()` the typed array refused the write
  (`Attempted to set an invalid (previously freed?) object instance into a
  'TypedArray'`) and the removed entity stayed behind in its slot. Dangling tail
  rows are now dropped first, matching the existing guard on `World.entities`.

## [9.2.0] - 2026-07-28 - Relationship deserialization fix + dependency tracking

### Fixed

- **Deserialized relationships were restored but unmatchable.**
  `GecsRelationshipData.to_relationship()` built an empty `Relationship.new()` and
  assigned `relation` afterwards. `Relationship` caches the relation's `Script` in
  `_init` (a hot-path optimization used by `matches()`), so a post-hoc assignment
  left that cache null and every comparison of a restored relationship against a
  probe failed. The relationship was still present in `entity.relationships`, which
  made the failure look like a matching bug rather than a serialization one. Every
  pattern-matched path broke for restored relationships: `get_relationship()`
  returned null, `has_relationship()` returned false, `remove_relationship()` removed
  nothing, and both `with_relationship()` / `without_relationship()` query filters
  (which post-filter through `has_relationship`) silently returned no matches.

  This bit any project that serializes a world and restores it, most visibly on a
  level swap that purges and reinstates persistent entities: ownership and inventory
  relationships came back inert, so the first `get_relationship(...).target` after
  the swap hit a null base. `to_relationship()` now resolves the target first and
  builds through `Relationship.new(relation, target)`, and `Relationship.relation`
  gained a setter that keeps `_relation_script` in sync so any future post-hoc
  assignment (deserialization, network replication) stays correct.

  The existing serialization suite only asserted that `relationship.target` was
  restored, never that the result was matchable, which is how this shipped. New
  coverage in `tests/core/test_relationship_serialization.gd` asserts matchability
  after a round trip for Entity, Component and Script targets, relation payload data
  through property-query relationships, `remove_relationship()`, and relationships
  surviving repeated purge/restore cycles.

### Added

- **`GECSTracker`: run a computation and learn its ECS data dependencies.**
  `GECSTracker.track(callable)` evaluates a callable with lightweight
  instrumentation on `QueryBuilder.execute()` and
  `Entity.get_component()` / `has_component()`, returning
  `{result, queries, reads}`: every query builder executed and every component
  type read, however deep in helper code the access happened. Intended for reactive
  derivations (subscribe an `Observer` to exactly the reported dependencies), cache
  invalidation, and tooling that audits what a function actually touches. While
  inactive (the default) the instrumentation costs a single static bool branch on
  those hot paths. Tracking is not re-entrant: `track()` calls must not nest.
  New suite: `tests/core/test_tracker.gd`.
- **`Entity.set_read_tracker()` and `QueryBuilder.set_execute_tracker()`**, the
  static hooks backing `GECSTracker`. Pass a valid `Callable` to install, or
  `Callable()` to clear.
- **`QueryBuilder.sensitivity()`**, a public view of the component script paths
  whose mutation could affect a query's membership, for building stable dependency
  signatures.
- **`QueryBuilder.has_relationship_filters()`**, to tell whether a query filters on
  relationships and therefore needs relationship events in a derived subscription.

## [9.1.1] - 2026-07-26 - Debugger duplication fixes

### Fixed

- **Entities and systems no longer appear duplicated in the debugger tab.** The
  v9.1.0 subscription handshake replays a full state snapshot on every
  `gecs:subscribe`, and subscribes fire several times per session (READY is
  announced by both the ECS autoload and `World.initialize()`, the editor
  subscribes again at session start, and once more on every category toggle or
  Hz change). The tab appended a fresh entity row on each replay and never freed
  system rows on removal, so replays and mid-session world swaps (scene reloads)
  doubled the lists. The tab is now idempotent: entity rows are deduped by
  instance id and updated in place (preserving expansion state, pin icons, and
  the disabled suffix), `system_removed` frees its tree row, `entity_removed`
  frees every matching row, and a `world_init` carrying a new world id clears
  all state left over from the previous world. `system_added` re-announcements
  (snapshot replays, `set_system_active` ACKs) now merge into the existing entry
  instead of wiping accumulated min/max/avg metrics. Pinned-item state is
  cleared with the rest of the data (it is keyed by instance id, which is
  meaningless across sessions and worlds). New regression suite:
  `tests/debug/test_editor_debugger_tab_dedup.gd`.
- **`World.add_entity()` and `add_system()` are now idempotent.** Re-adding an
  entity or system the world already tracks silently doubled it (a doubled
  system genuinely ran twice per frame) and double-announced it to the
  debugger. Both now log a debug line and return. New tests in
  `tests/core/test_world.gd`.
- **Debugger snapshots replay disabled state**, so a tab attaching after an
  entity was disabled shows it correctly. The `entity_disabled`/`entity_enabled`
  debugger messages also no longer log errors for entities outside the scene
  tree.

### Added

- **`example_inventory/`**: a complete grid-inventory sample (components,
  systems, item actions, and UI) ported from ZAMN, showing entity-per-item
  inventory modeling on GECS.

## [9.1.0] - 2026-07-24 - Debugger instrumentation overhaul

The v9 performance line made the simulation fast; this release gives the editor
debugger the same treatment. With `gecs/settings/debug_mode = true`, the runtime
now produces **nothing** until the GECS editor tab actually subscribes — the
per-`world.process()` instrumentation cost drops from **~20 ms/call to ~0.009 ms/call**
(1000 entities, one no-match system, headless), matching debug-off. Attached cost
is bounded by sampling telemetry at the tab's chosen rate instead of every frame.

This release also officially raises the minimum supported Godot version to 4.6
and hardens two crash classes: systems that remove themselves (or their whole
group) mid-frame, and relationships whose target entity was freed outside
`remove_entity()`.

### Added

- **Subscription handshake over the existing `gecs` capture channel.** On start the
  game sends `gecs:ready`; the editor tab replies with `gecs:subscribe` carrying
  per-category flags and a telemetry sample rate. The game only builds and sends what
  a live, subscribed tab asked for. On subscribe the game replays a full state
  snapshot (`World._send_debugger_snapshot()`) so the tab populates immediately.
- **Category toggles in the debugger tab** — Lifecycle (entity/component/relationship
  events), Property changes, and System metrics can each be enabled/disabled live, plus
  a metrics sample-rate (Hz) control. The game produces only the enabled categories.
- **`World.perf_instrumentation`** opt-in flag. The per-query `perf_mark` timing
  (which nothing in the framework consumed) is now off even when `debug_mode` is on;
  profiling tooling sets this flag explicitly before reading `perf_get_frame_metrics()`.
- **New tests**: `tests/debug/test_debugger_gating.gd` (no builds/sends when unattached;
  full flow when attached) and `tests/debug/test_debugger_subscription.gd` (handshake,
  category flags, snapshot, reset-metrics routing), via a test-sink seam on
  `GECSEditorDebuggerMessages`.

### Changed

- **Minimum supported Godot version is now officially 4.6.** The per-system
  performance monitor (added in v8.0.0) registers via the `MonitorType`
  parameter of `Performance.add_custom_monitor()`, which does not exist in
  Godot 4.5 or earlier. On those versions `system.gd` fails to parse and the
  failure cascades until the `_ECS` autoload cannot instantiate (issue #115,
  misdiagnosed as a type-annotation deadlock in PR #119). GECS has therefore
  been de-facto 4.6+ since v8.0.0; this makes it official instead of adding
  version-gated compatibility code. CI now runs on Godot 4.6 (was 4.5,
  red since 2026-04-25 because of this). The last release that supports
  Godot 4.5 is v7.1.0.
- **Per-system telemetry is sampled/throttled** to the tab's subscribed Hz rather than
  emitted every frame per system.
- **System debug name is cached once** at `_internal_setup()` — the per-frame
  `get_script().resource_path.get_file().get_basename()` string work in `System._handle`
  is gone. `lastRunData` building remains gated on `ECS.debug` (it is a documented
  user-facing debug feature); only the debugger *send* is gated on an attached subscription.
- **The `gecs` message capture is registered once on the `ECS` autoload** (process
  lifetime) instead of per-`World`.

### Fixed

- **Crash when a system removed itself as the last system in its group.**
  `remove_system()` erases an emptied group key, and `world.process()` then
  re-read that key for the PER_GROUP command-buffer flush, crashing mid-frame.
  The flush now re-checks the key, `remove_system()` guards the group lookup
  (fixing a latent double-remove crash), and `remove_system_group()` iterates a
  copy of the group so erasing from the live array no longer skips every other
  system. `world.process()` also no longer skips the system that shifts into
  the vacated slot when a peer removes itself mid-frame (slot re-check, no
  per-frame array copy). New tests in `tests/core/test_system_removal.gd`.
- **Dangling relationship targets no longer crash the framework.** An entity
  freed outside `remove_entity()` (direct `free()`/`queue_free()` teardown)
  leaves relationships holding a freed target. On Godot 4 a freed object
  compares equal to `null` but hard-errors as the left operand of `is`, which
  crashed query cache key hashing, archetype signature calculation, structural
  query building, save serialization, network relationship sync, and the
  debugger's relationship formatter (and where a `== null` check ran first, the
  freed target silently behaved as a wildcard instead). Dangling relationships
  are now inert everywhere: they match no queries, produce no archetype slot
  keys, are dropped from `GECSIO` saves, are skipped by network relationship
  sync, and report `valid() == false` so `get_relationship(s)` lazily prunes
  them. `remove_entity()` and `purge()` also compact dangling refs out of the
  entity list instead of erroring on the typed-array write. New tests in
  `tests/core/test_dangling_relationship_target.gd` and
  `tests/network/test_sync_relationship_handler.gd`.
- **`GECSIO.save` now creates missing destination directories.** `ResourceSaver`
  does not, so saving to a folder that never existed (fresh checkout, first run
  on a new machine) always failed. This is why every serialization test failed
  in CI: `reports/` is gitignored and absent there, present in dev checkouts.
- **Godot 4.6 parse errors from type inference through the ECS autoload.** Three
  locals (`_perf` twice in `world.gd`, `measure_time` in `system.gd`) used `:=`
  inference on expressions involving `ECS.debug`. Godot 4.6's analyzer cannot
  resolve the autoload's member types while parsing inside the ecs.gd dependency
  cycle (4.7 can), so the scripts failed to parse and the `_ECS` autoload could
  not instantiate. Now annotated `: bool` explicitly.
- **~20 ms/`world.process()` instrumentation cost with `debug_mode` on and no debugger
  attached** — every message send hit an engine `Capture not registered: 'gecs'` error
  (I/O) several times per frame. Sends are now gated on a live subscription; the error
  spam is gone.
- **Reset Metrics button did nothing.** The tab sent a bare `reset_system_metrics`; the
  game-side capture routing requires the `gecs:` prefix, so the message never arrived.
  Now sends `gecs:reset_system_metrics`.
- **Debugger capture leaked to a freed `World` after a world swap.** Registration was
  bound to a `World` instance method and guarded by `has_capture`, so once that world
  was freed no new world ever re-registered. Moving registration to the `ECS` autoload
  fixes it; editor→game world ops are forwarded to the current `ECS.world`.

## [8.0.0] - 2026-04-21 - Observer API overhaul

### Breaking Changes

- **Legacy Observer API removed.** `watch() -> Resource`, `match() -> QueryBuilder`, and the fixed callbacks `on_component_added` / `on_component_removed` / `on_component_changed` are gone — no shim. Observers must now override `query() -> QueryBuilder` with event modifiers chained on it (`.on_added()`, `.on_removed()`, `.on_changed([&"prop"])`, `.on_match()`, `.on_unmatch()`, `.on_relationship_added([...])`, `.on_relationship_removed()`, `.on_event(&"name")`) plus a single unified `each(event, entity, payload)` callback. See **[MIGRATION_LEGACY_OBSERVER.md](addons/gecs/docs/MIGRATION_LEGACY_OBSERVER.md)**.
- **Project Settings namespace migration**: `gecs_network/sync/*` renamed to `gecs/network/sync/*`.
  All four settings are affected:
  - `gecs_network/sync/high_hz` → `gecs/network/sync/high_hz`
  - `gecs_network/sync/medium_hz` → `gecs/network/sync/medium_hz`
  - `gecs_network/sync/low_hz` → `gecs/network/sync/low_hz`
  - `gecs_network/sync/reconciliation_interval` → `gecs/network/sync/reconciliation_interval`

  **Migration**: Open Project Settings and update any overrides from the old paths to the new ones. Default values are unchanged.

### Added

- **New migration guide** at `addons/gecs/docs/MIGRATION_LEGACY_OBSERVER.md` covering the v7→v8 Observer translation with Quick Reference table and step-by-step examples.
- **Editor-only `push_warning`** when `Observer.query()` returns a `QueryBuilder` with no event modifiers — catches the silent no-op footgun at dev time.

### Changed

- **Addon merge**: `addons/gecs_network/` has been merged into `addons/gecs/network/`. The GECS Network module is now included in the main GECS addon — no separate plugin install needed. Enable the `gecs` plugin only; all networking classes are available immediately.
- Network test files moved from `addons/gecs_network/tests/` to `addons/gecs/tests/network/`.
- New `GECSNetworkSettings` class with typed constants for all `gecs/network/sync/*` setting paths.
- **`addons/gecs/docs/OBSERVERS.md`** fully rewritten to document the new API (query + event modifiers + each, sub_observers, monitors, custom events, yield_existing, active/paused, cmd, FlushMode).
- **`sub_observers()` tuple shape** simplified to `[QueryBuilder, Callable, optional yield_existing_override]`. The previously-documented-but-unimplemented `SystemTimer` slot has been removed. Observers are event-driven; for throttled observer work use `FlushMode.MANUAL` + `cmd.add_custom(callable)` inside `each()` and flush from a timed System.
- **`on_changed()`, `on_relationship_added()`, `on_relationship_removed()`** now append-and-dedup their filter lists across chained calls (previously replaced). `.on_changed([&"a"]).on_changed([&"b"])` accumulates both property filters, matching the semantics of `on_event()` and `with_group()`.

### Fixed

- **Observer queries with `with_group` / `without_group` / `enabled()` / `disabled()` now filter correctly** in dispatch. These were silently ignored in v7.x — code that accidentally depended on the bug (i.e., observers firing for entities outside the group or in the wrong enabled state) will now fire less. This is the intended behavior.
- **`on_removed` / `on_relationship_removed`** now evaluate property queries and group/enabled filters in the match-before-removal check — previously only structural component membership was checked. Property-query match-before-removal evaluates against the detached component payload, so pre-removal property state is preserved.
- **Relationship property queries in match-before-removal** (`on_relationship_removed` with `with_relationship([Relationship.new({C_X: {...}}, null)])`) now evaluate the removed relationship's property criteria via `Relationship.matches()`. Previously any removal of a matching relation type would fire `RELATIONSHIP_REMOVED` even if the removed rel didn't satisfy the property query.
- **`Entity.remove_relationships([...])`** now erases and emits per-rel as it removes, rather than batch-then-replay. Multi-relationship `on_relationship_removed()` observers (`with_relationship([RelA, RelB]).on_relationship_removed()`) now fire correctly on batch removals — previously all rels were gone before any signal fired, so match-before-removal failed for all of them.
- **`yield_existing` and monitor seeding** iterate snapshots — mutating callbacks (e.g. `remove_entity` from inside a `MATCH` handler) can no longer skip remaining entries or crash on invalidated instances.
- **Monitor membership is seeded at `add_observer()` regardless of `active` / `paused` state** — flipping `active = true` later no longer leaves pre-existing matching entities stuck outside membership (which caused `UNMATCH` to never fire for them).
- **`remove_observer`** now flushes pending MANUAL-mode command buffers before freeing the observer — queued work is no longer silently dropped.
- **Re-entrancy safety**: dispatch entries are snapshotted so observers registered inside another observer's callback do not receive the event that caused their creation. `yield_existing` callbacks iterate an entity snapshot; monitor evaluation iterates a dedup snapshot. All mutation-safe.

## [7.3.0] - 2026-04-07 - SystemTimer + FlushMode Enum

### Added

- **SystemTimer tick rate control** — Systems can now run at fixed intervals instead of every frame. Call `set_tick_rate(seconds)` in `setup()` to throttle a system. Multiple systems can share the same `SystemTimer` instance for guaranteed synchronized execution on the same frame. Supports repeating (interval) and one-shot (timeout) modes. Overshoot is carried forward to prevent drift.
  - New class: `SystemTimer` (`addons/gecs/ecs/system_timer.gd`)
  - New property: `System.tick_source: SystemTimer`
  - New method: `System.set_tick_rate(interval, single_shot?) -> SystemTimer`
  - World advances all unique timers per group before running systems
- **SystemTimer tests** — 17 tests covering unit behavior and system integration (interval, shared timers, one-shot, pause, groups, overshoot)

### Changed

- **`command_buffer_flush_mode` is now a `FlushMode` enum** instead of a `String`. This eliminates per-frame string comparisons — all flush mode checks are now int comparisons. The `_flush_mode` internal cache variable and the string-to-int conversion in `_internal_setup()` have been removed.
  - **Migration**: Change `command_buffer_flush_mode = "PER_GROUP"` to `command_buffer_flush_mode = FlushMode.PER_GROUP` (same for `PER_SYSTEM` and `MANUAL`)
- Updated all documentation to reflect FlushMode enum and SystemTimer APIs

### Fixed

- `s_random_spawner.gd` example was assigning `FlushMode.PER_GROUP` (enum) to a `String`-typed export, causing a parse error

## [6.9.0] - 2026-03-16 - GECS Network + Core Reliability Audit

## Summary

6.9.0 is a dual release: it ships **GECS Network**, a new multiplayer synchronization addon, and a **5-phase core reliability audit** that hardened the observer signal chain, query cache, archetype edge cases, component lifecycle, and hot-path performance.

---

## Core Reliability Audit

### Phase 1 — Observer Signal Chain

Fixed three correctness bugs in the observer/reactive system that caused ghost connections and missed or double-fired notifications.

**Fixed:**

- **OBS-03** — `property_changed` signal was not disconnected in `remove_component()` or `_initialize()`, causing ghost connections that fired on stale entities. Fixed by disconnecting in both paths and using a shallow duplicate for pre-world components instead of the original reference.
- `remove_entity()` teardown order guaranteed: components are disconnected before the entity is freed.
- Observer doc-comments updated to document the three guaranteed behaviors.

**Tests added:**

- `test_observers.gd` — regression scaffold for OBS-01, OBS-02, OBS-03 (19 cases, all green)
- `O_InstanceCapturingObserver` test helper for deterministic observer testing

---

### Phase 2 — Cache Invalidation Scoping

Fixed four cache invalidation bugs that caused stale query results during nested structural changes.

**Fixed:**

- **CACHE-01** — Cache was never invalidated when a component was added to an entity that already had components (boolean `_invalidating` flag blocked re-entry). Replaced flag with a depth counter so nested invalidations complete correctly.
- **CACHE-02** — Cache invalidated too broadly: any structural change wiped the entire cache. Scoped invalidation to only affected archetypes.
- **CACHE-04** — Invalidation did not fire when entities were removed from the world mid-query.

**Tests added:**

- `test_cache_invalidation.gd` — 4 RED regression tests covering CACHE-01/02/03/04, all turned GREEN

---

### Phase 3 — Archetype Edge Cache Hardening

Fixed three archetype transition edge cases that produced incorrect query results after component additions/removals.

**Fixed:**

- **ARCH-01** — After removing a component, the entity's archetype was not updated in `entity_to_archetype`, causing future queries to return it under the wrong archetype.
- **ARCH-02** — Adding a component to an entity caused it to appear in both old and new archetype buckets simultaneously.
- **ARCH-03** — Neighbor tracking added to `Archetype` — each archetype now tracks which archetypes it transitions to on add/remove, enabling targeted cache invalidation instead of full-cache sweeps.

**Tests added:**

- 5 RED regression tests for ARCH-01/02/03, all turned GREEN after fixes

---

### Phase 4 — Component Lifecycle and Relationship Queries

Fixed component duplication semantics and removed a dead relationship query API.

**Fixed:**

- **COMP-01/COMP-03** — `duplicate(true)` (deep copy) was used when cloning components, which erased non-`@export` runtime properties. Replaced with a shallow property copy that preserves all vars while still producing a distinct instance.
- `remove_entity()` — `remove_child()` now called synchronously before `queue_free()` to prevent a one-frame window where the entity node still exists in the tree after removal.
- Guard added to the `q` getter against nil `ECS.world` to prevent orphan scanner crashes.

**Removed:**

- `with_reverse_relationship()` from `QueryBuilder` — dead API with no tests, no callers, no documentation. Removed along with the backing `reverse_relationship_index` dict in `world.gd`.

**Tests added:**

- RED regression tests for COMP-01 and COMP-03 non-`@export` property preservation

---

### Phase 5 — Performance Baselines and Regression Infrastructure

Applied two hot-path optimizations to the observer notification path and validated with JSONL benchmarks.

**Optimized:**

- **PERF-02** — `watch()` virtual method was called on every component change event (once per observer per notification). Now called once at `add_observer()` time; result cached in `_observer_watch_cache: Dictionary`. Eliminated per-notification virtual dispatch overhead.
- **PERF-01** — `_handle_observer_component_added` and `_handle_observer_component_changed` used `Array.has(entity)` (O(N) scan) to check entity membership in query results. Replaced with `entities_matching.has(entity)` against the `_query()` result array — correct semantics with O(1) dict lookup.

**Benchmark results (4.6-stable, 10,000 entities):**

- `observer_component_additions`: 3789ms → **1362ms** (−64%)
- `query_caching`: 3.794ms → 4.218ms (within noise — no regression)

**Infrastructure:**

- Pre-fix and post-fix JSONL baselines recorded in `reports/perf/` for all benchmark categories
- Debugger now supports `--instance-id` flag to target specific Godot instances during debugging sessions

---

## GECS Network — Multiplayer Synchronization Addon

This Version also adds **GECS Network**, a new addon that provides multiplayer entity synchronization for GECS-based games. It enables networked gameplay by automatically synchronizing entities, components, and their properties across clients using Godot's built-in multiplayer system.

## Key Features

### 🎮 Two Sync Patterns

1. **Spawn-Only Sync** - For deterministic entities (projectiles, effects)
   - Sync once at spawn, clients simulate locally
   - Minimal bandwidth usage
   - Perfect for predictable behavior

2. **Continuous Sync** - For dynamic entities (players, enemies)
   - Real-time position/state updates via MultiplayerSynchronizer
   - Native Godot networking integration
   - Configurable update rates and interpolation

### 🔧 Project-Agnostic Design

- **No hardcoded components** - Fully configurable via `SyncConfig`
- **Generic implementation** - Works with any GECS project
- **Middleware pattern** - Clean separation between generic addon and project-specific logic
- **Signal-based reactive architecture** - Optimal for async networking

### 📦 Component-Based Configuration

```gdscript
class_name ProjectSyncConfig
extends SyncConfig

func _init() -> void:
    component_priorities = {
        "C_Velocity": Priority.HIGH,
        "C_Health": Priority.MEDIUM,
        "C_NetworkIdentity": Priority.LOW,
    }
    transform_component = "C_Transform"
    model_ready_component = "C_Instantiated"
```

### 🏗️ Three-Layer Architecture

```
┌─────────────────────────────────────┐
│  addons/gecs/network/               │ ← Generic, reusable module
│  - NetworkSync (signals, RPCs)      │
│  - SyncConfig (configuration)       │
│  - Network components                │
└─────────────────────────────────────┘
              ↓ signals
┌─────────────────────────────────────┐
│  game/network/NetworkMiddleware     │ ← Optional project layer
│  - Project-specific networking      │
│  - Visual property handling          │
└─────────────────────────────────────┘
              ↑ uses
┌─────────────────────────────────────┐
│  game/                              │ ← Game code
│  - ProjectSyncConfig                │
│  - Components & Systems              │
└─────────────────────────────────────┘
```

## What's Included

### Core Files

- `network_sync.gd` - Main synchronization orchestrator (signal-based)
- `sync_config.gd` - Configuration resource for component priorities and filtering
- `net_adapter.gd` - Multiplayer API abstraction layer
- `sync_component.gd` - Base class for components with network sync
- `plugin.gd` / `plugin.cfg` - Godot plugin integration

### Components

- `C_NetworkIdentity` - Authority and ownership tracking
- `C_SyncEntity` - Enables continuous synchronization
- `C_LocalAuthority` - Marker for locally controlled entities
- `C_RemoteEntity` - Marker for remotely controlled entities
- `C_ServerOwned` - Marker for server-owned entities

### Documentation

- `README.md` - Complete usage guide with examples
  - Quick start (5 steps)
  - Sync pattern explanations
  - Component serialization guide
  - Troubleshooting section
  - Best practices

## Technical Highlights

### Signal-Based Reactive Architecture

Unlike traditional ECS systems that process sequentially, networking is inherently async/parallel. This addon uses Godot signals for immediate reactive responses to component changes, making it ideal for networked games.

### Component Serialization

Components automatically sync `@export` properties at spawn:

```gdscript
class_name C_Projectile
extends Component

@export var damage: int = 0        # Synced at spawn
@export var speed: float = 10.0    # Synced at spawn
@export var color: Color = Color.WHITE  # Synced at spawn
```

### Authority Model

```gdscript
C_NetworkIdentity.new(0)   # Server-owned (enemies, projectiles)
C_NetworkIdentity.new(1)   # Host player
C_NetworkIdentity.new(N)   # Client player (peer_id > 1)
```

### Bandwidth Optimization

- Priority-based update queuing (HIGH/MEDIUM/LOW)
- Configurable component filtering
- Transform batching (position + rotation)
- Spawn-only sync for deterministic entities

## Integration Example

```gdscript
# In your main scene:
func _setup_network_sync() -> void:
    var network_sync = NetworkSync.attach_to_world(world, ProjectSyncConfig.new())
    network_sync.debug_logging = true
```

That's it! The addon handles all entity and component synchronization automatically.

## Why Add This to GECS?

1. **Completes the ECS Framework** - GECS provides local game logic; the GECS network module adds multiplayer
2. **Zero-Configuration Networking** - Projects just attach NetworkSync and define their SyncConfig
3. **Godot-Native** - Uses built-in MultiplayerAPI, no external dependencies
4. **Production Ready** - Clean, documented
5. **Community Value** - Multiplayer is a common need for GECS users

## License

This addon is contributed under the same CC0-1.0 license as GECS (public domain).

## Credits

Developed by **Code Fixxers** team during the Arena Survivors MVP project.

Additional Dev work by @csprance

## [6.8.0] - CommandBuffer System

### New Features

#### CommandBuffer System

Callable-based deferred execution buffer for safe structural ECS changes during iteration. Eliminates the need for backwards iteration or defensive snapshots.

**New Files:**

- `addons/gecs/ecs/command_buffer.gd` — CommandBuffer class (extends RefCounted)

**API:**

```gdscript
# Inside any System, use the cmd property:
cmd.add_component(entity, component)
cmd.remove_component(entity, component_type)
cmd.add_entity(entity)
cmd.remove_entity(entity)
cmd.add_relationship(entity, relationship)
cmd.remove_relationship(entity, relationship, limit)
cmd.add_custom(callable)
```

**Flush Modes** (configurable per-system via `command_buffer_flush_mode`):

- **PER_SYSTEM** (default) — executes after each system completes
- **PER_GROUP** — executes after all systems in the group complete
- **MANUAL** — requires explicit `ECS.world.flush_command_buffers()` call

**Architecture:**

- Each queue method appends a lambda to `Array[Callable]` with baked-in `is_instance_valid` guard
- Commands execute in exact queued order (preserves user intent)
- Single cache invalidation per `execute()` call
- Statistics tracking: `commands_queued`, `commands_executed`, `last_execution_time_ms`

**Migration:**

```gdscript
# Before (backwards iteration)
for i in range(entities.size() - 1, -1, -1):
    if should_delete(entities[i]):
        ECS.world.remove_entity(entities[i])

# After (CommandBuffer)
for entity in entities:
    if should_delete(entity):
        cmd.remove_entity(entity)
```

### Modified

- **System** (`system.gd`): Added `cmd: CommandBuffer` property (lazy-initialized), `command_buffer_flush_mode` export, `has_pending_commands()` helper, auto-flush logic
- **World** (`world.gd`): Added `flush_command_buffers()`, PER_GROUP flush logic in `process()`, deferred system setup via `finalize_system_setup()`
- **ECS** (`ecs.gd`): Calls `world.finalize_system_setup()` after assigning `ECS.world` to fix system setup timing

### Fixed

- **System setup timing**: Systems were calling `setup()` before `ECS.world` was assigned. Now deferred until world is available.

### Tests

- `test_command_buffer.gd` — Unit tests for all command types, freed entity handling, cache invalidation
- `test_command_buffer_integration.gd` — Integration tests for PER_SYSTEM, PER_GROUP, and MANUAL flush modes
- `test_command_buffer_perf.gd` — Performance benchmarks comparing backwards iteration vs CommandBuffer

### External

- `addons/gdUnit4/src/core/GdUnitFileAccess.gd` — Removed deprecated `true` parameter from `get_as_text()`

## [6.7.2] - 2025-11-29 - Critical Query Cache Bugfix

### Fixed

- **CRITICAL:** Fixed query cache bug causing stale results when entities moved between existing archetypes
  - QueryBuilder.execute() caches full entity lists, not just archetype matches
  - Cache invalidation now triggers on all structural changes (component add/remove, entity removal)
  - Previously only invalidated when NEW archetypes were created, missing entities moving to EXISTING archetypes
  - Example bug: DeathSystem would miss entities that added C_Dead after the first entity created the archetype
  - Performance impact: ~20% more cache invalidations, but correctness is critical

## [6.7.1] - Previous Release

### Removed

- Removed the unused QueryBuilder pooling infrastructure; `World.query` now always creates a fresh builder while retaining cache invalidation wiring for clarity and predictable lifecycle management.

## [5.0.0] - 2025-10-15 - Major ECS Overhaul & Performance Awesomeness (Some Small Breaking Changes)

**GECS v5.0.0 is a major release with massive performance improvements, API simplification, and relationship system overhaul.**

This release combines all improvements from v5.0.0-rc1 through v5.0.0-rc4, delivering the most performant and cleanest GECS API to date.

### 📦 What's in This Release

**3 Breaking Changes:**

1. **Entity.on_update() removed** - Enforces proper ECS separation of concerns
2. **System.process_all() no longer returns bool** - Simplified internal API
3. **Relationship system overhaul** - Removed weak/strong matching in favor of component queries

**Major Performance Improvements:**

1. **Query cache key optimization** - 85% faster cache key generation
2. **Query system speedup** - 96-99% faster for cached queries
3. **System processing** - 2-7% faster across all benchmarks
4. **Linear scaling** - Query system now scales linearly instead of exponentially

**New Features:**

1. **Target component queries** - Query both relation and target entity properties
2. **Limited relationship removal** - Remove specific number of relationships
3. **Topological sort fix** - System dependencies now execute in correct order
4. **Improved test suite** - Zero orphan nodes, proper lifecycle management

### ⚠️ BREAKING CHANGES

#### Entity.on_update() Lifecycle Method Removed

The `on_update(delta)` lifecycle method has been removed from the Entity class:

- **`on_update(delta)` method removed** - This lifecycle hook is no longer called
- **Use Systems instead** - Entity logic should be handled by Systems, not in Entity methods
- **Cleaner separation of concerns** - Entities are data containers, Systems contain logic

**Migration:**

| Old (v4.x)                                   | New (v5.0)                                |
| -------------------------------------------- | ----------------------------------------- |
| Override `on_update(delta)` in Entity class  | Create a System that processes the entity |
| `entity.on_update(delta)` called every frame | System.process(entity, delta)             |

**Example Migration:**

```gdscript
# ❌ Old (v4.x) - Logic in Entity
class_name MyEntity extends Entity:
    func on_update(delta: float):
        # Entity logic here
        position += velocity * delta

# ✅ New (v5.0) - Logic in System
class_name MySystem extends System:
    func query():
        return q.with_all([C_Transform, C_Velocity])

    func process(entity: Entity, delta: float):
        var transform = entity.get_component(C_Transform)
        var velocity = entity.get_component(C_Velocity)
        transform.position += velocity.direction * velocity.speed * delta
```

**Why this change?**
This enforces proper ECS architecture where Entities are pure data containers and all logic lives in Systems. This makes code more modular, testable, and performant.

#### System.process_all() and System.\_process_parallel() No Longer Return Booleans

The `process_all()` and `_process_parallel()` methods now return `void` instead of `bool`:

- **`did_run` variable removed** - Internal tracking variable was never used
- **Return type changed from `bool` to `void`** - Return values were never checked or used
- **No functional impact** - These were internal implementation details

**Migration:**

| Old (v4.x)                                         | New (v5.0)                                |
| -------------------------------------------------- | ----------------------------------------- |
| `var result = system.process_all(entities, delta)` | `system.process_all(entities, delta)`     |
| Override `process_all()` returning `bool`          | Override `process_all()` returning `void` |

**Why this change?**
The boolean return values were historical artifacts that were never actually used anywhere in the codebase. Removing them simplifies the API and makes the code cleaner.

#### Removed Weak/Strong Matching System

The weak/strong matching system has been completely replaced with a simpler, more intuitive approach:

- **`weak` parameter removed** from all relationship methods
- **`Component.equals()` method removed** - use component queries instead
- **Type matching is now the default** - matches by component type only
- **Component queries for property matching** - use dictionaries for property-based filtering

**Migration:**

| Old (v4.x)                                                                | New (v5.0)                                                                           |
| ------------------------------------------------------------------------- | ------------------------------------------------------------------------------------ |
| `entity.has_relationship(Relationship.new(C_Eats.new(5), target), false)` | `entity.has_relationship(Relationship.new({C_Eats: {'value': {"_eq": 5}}}, target))` |
| `entity.has_relationship(Relationship.new(C_Eats.new(), target), true)`   | `entity.has_relationship(Relationship.new(C_Eats.new(), target))`                    |
| `entity.get_relationship(rel, true, true)`                                | `entity.get_relationship(rel)`                                                       |
| `entity.get_relationships(rel, true)`                                     | `entity.get_relationships(rel)`                                                      |
| Override `equals()` in component                                          | Use component queries: `{C_Type: {'prop': {"_eq": value}}}`                          |

#### Component Query Improvements

- **Target component queries added** - Query both relation AND target component properties
- **Cannot add query relationships to entities** - Queries are for matching only, not storage
- **Fixed bug with falsy values** - Component queries now correctly handle `0`, `false`, etc.

### ✨ New Features

#### Simplified Relationship Matching

```gdscript
# Type matching (default) - matches by component type
entity.has_relationship(Relationship.new(C_Damage.new(), target))

# Component query - matches by property criteria
entity.has_relationship(Relationship.new({C_Damage: {'amount': {"_gte": 50}}}, target))

# Query both relation AND target
var strong_buffs = ECS.world.query.with_relationship([
    Relationship.new(
        {C_Buff: {'duration': {"_gt": 10}}},
        {C_Player: {'level': {"_gte": 5}}}
    )
]).execute()
```

#### Target Component Queries (NEW!)

```gdscript
# Query relationships by target component properties
var high_hp_targets = ECS.world.query.with_relationship([
    Relationship.new(C_Targeting.new(), {C_Health: {'hp': {"_gte": 100}}})
]).execute()

# Mix relation and target queries
var critical_effects = ECS.world.query.with_relationship([
    Relationship.new(
        {C_Damage: {'type': {"_in": ["fire", "ice"]}}},
        {C_Entity: {'level': {"_gte": 10}}}
    )
]).execute()
```

#### Limited Relationship Removal

```gdscript
# Remove specific number of relationships
entity.remove_relationship(Relationship.new(C_Damage.new(), null), 1)  # Remove 1 damage
entity.remove_relationship(Relationship.new(C_Buff.new(), null), 3)    # Remove up to 3 buffs

# Combine with component queries
entity.remove_relationship(
    Relationship.new({C_Damage: {'amount': {"_gt": 20}}}, null),
    2  # Remove up to 2 high-damage effects
)
```

### 🚨 Migration Guide

#### 1. Remove `weak` Parameters

```gdscript
# ❌ Old (v4.x)
entity.has_relationship(rel, true)
entity.get_relationship(rel, true, true)
entity.get_relationships(rel, false)

# ✅ New (v5.0)
entity.has_relationship(rel)
entity.get_relationship(rel)
entity.get_relationships(rel)
```

#### 2. Replace Strong Matching with Component Queries

```gdscript
# ❌ Old (v4.x) - strong matching for exact values
entity.has_relationship(Relationship.new(C_Eats.new(5), target), false)

# ✅ New (v5.0) - component query
entity.has_relationship(Relationship.new({C_Eats: {'value': {"_eq": 5}}}, target))
```

#### 3. Remove `equals()` Overrides

```gdscript
# ❌ Old (v4.x) - custom equals() method
class_name C_Damage extends Component:
    @export var amount: int = 0

    func equals(other: Component) -> bool:
        return amount == other.amount

# ✅ New (v5.0) - use component queries
# No equals() method needed!
# Query by property: {C_Damage: {'amount': {"_eq": 50}}}
```

#### 4. Check any deps function and sorting order

Topological sort was broken in previous versions. It is now fixed and as a result some systems may now be running in the correct order defined in the deps
but it may end up to be the wrong order for your game code. Check these depenencies by doing: `print(ECS.world.systems_by_group)` this will show you the sorted
systems and how they are running. Do a comparison between this version and the previous versions of GECS.

### 🧪 Test Suite Improvements

#### Performance Test Cleanup

- **Eliminated orphan nodes** - Refactored all performance tests to use `scene_runner` pattern
- **Proper lifecycle management** - Tests now use `auto_free()` and `world.purge()` for cleanup
- **Consistent test structure** - All performance tests follow same pattern as core tests
- **Zero orphan nodes** - Performance tests now maintain clean test environment

**Files Updated:**

- `addons/gecs/tests/performance/performance_test_base.gd` - Uses scene_runner for proper test setup
- `addons/gecs/tests/performance/performance_test_entities.gd` - Refactored to use auto_free pattern
- `addons/gecs/tests/performance/performance_test_components.gd` - Simplified cleanup using world.purge
- `addons/gecs/tests/performance/performance_test_queries.gd` - Removed manual cleanup code
- `addons/gecs/tests/performance/performance_test_systems.gd` - Uses scene_runner for world management
- `addons/gecs/tests/performance/performance_test_integration.gd` - Consistent with core test patterns
- `addons/gecs/tests/performance/performance_test_system_process.gd` - Proper node lifecycle management

### 🚀 Performance Improvements

#### Massive Query Cache Key Optimization (from v5.0.0-rc4)

**85% faster cache key generation** leading to dramatic query performance improvements:

- **Cache key generation**: 283ms → 43ms (**85% faster**)
- **Query caching**: 500ms → 4.7ms (**99% faster**)
- **Query with all**: 13ms → 0.55ms (**96% faster**)
- **Query with any**: 27ms → 5.6ms (**79% faster**)
- **Complex queries**: Significantly improved scaling

**Technical Details:**

- Replaced expensive `str(comp)` fallbacks with direct `get_instance_id()` calls
- Eliminated conditional checks in cache key generation hot path
- Implemented polynomial rolling hash with XOR for collision resistance
- Used different prime multipliers (31, 37, 41) for component type separation

**Impact:**

- Query system now scales linearly instead of exponentially
- ECS performance optimized for large-scale applications (10,000+ entities)
- No performance regressions in any core ECS operations
- Cache effectiveness dramatically improved

#### System Processing Improvements (from v5.0.0 final)

Removing unused internal tracking improved system performance:

- **system_processing** (10k): 25.256ms → 24.183ms (**4.2% faster**)
- **multiple_systems** (10k): 136.064ms → 132.285ms (**2.8% faster**)
- **system_no_matches** (10k): 0.081ms → 0.075ms (**7.4% faster**)

Removing unused boolean returns and `did_run` tracking reduced conditional logic and CPU overhead.

### 📦 Files Changed in This Release

**Core Framework Changes:**

- `addons/gecs/ecs/entity.gd` - **BREAKING**: Removed `on_update()` lifecycle method and weak parameters from relationship methods
- `addons/gecs/ecs/system.gd` - **BREAKING**: `process_all()` and `_process_parallel()` now return `void` instead of `bool`
- `addons/gecs/ecs/relationship.gd` - **BREAKING**: Removed weak parameter, added target_query support
- `addons/gecs/ecs/component.gd` - **BREAKING**: Removed `equals()` method
- `addons/gecs/ecs/world.gd` - System dependency topological sort fixes
- `addons/gecs/ecs/ecs.gd` - Updated for new system processing

**Library Updates:**

- `addons/gecs/lib/component_query_matcher.gd` - **FIXED**: Properly handle falsy values (0, false, etc.)

**Documentation Updates:**

- `addons/gecs/docs/CORE_CONCEPTS.md` - Updated entity lifecycle and system examples
- `addons/gecs/docs/RELATIONSHIPS.md` - Complete rewrite for new relationship system
- `addons/gecs/docs/CLAUDE.md` - Updated with new relationship patterns
- `CHANGELOG.md` - Comprehensive v5.0.0 documentation
- `README.md` - Updated for v5.0.0 release

**Test Updates:**

- `addons/gecs/tests/core/test_relationships.gd` - Updated all tests to new API
- `addons/gecs/tests/systems/s_performance_test.gd` - Updated for new system signatures
- `addons/gecs/tests/systems/s_noop.gd` - New test helper system
- `addons/gecs/tests/performance/test_hotpath_breakdown.gd` - New performance test

**Example Updates:**

- `example/main.gd` - Updated to use v5.0.0 API
- `example/systems/s_velocity.gd` - Updated system implementation
- `example/systems/s_random_velocity.gd` - Updated system implementation

### 📜 Release Candidate History

This v5.0.0 release consolidates all improvements from the RC phase:

**v5.0.0-rc1 (Relationship System Overhaul):**

- Removed weak/strong matching system
- Introduced component queries for relationships
- Added target component queries
- Fixed topological sort for system dependencies

**v5.0.0-rc2 & rc3 (Test Suite Improvements):**

- Eliminated orphan nodes in performance tests
- Proper lifecycle management with `auto_free()` and `world.purge()`
- Consistent test structure across all test suites
- Zero memory leaks in test environment

**v5.0.0-rc4 (Query Performance Revolution):**

- 85% faster cache key generation
- 96-99% faster query caching
- Linear scaling instead of exponential
- Optimized hash algorithms with collision resistance

**v5.0.0-final (API Cleanup):**

- Removed `Entity.on_update()` lifecycle method
- Simplified `System.process_all()` to return `void`
- Updated documentation for proper ECS patterns
- 2-7% faster system processing

### 🌟 Community & Support

- **Discord**: [Join our community](https://discord.gg/eB43XU2tmn)
- **Documentation**: [Complete guides](addons/gecs/README.md)
- **Issues**: [Report bugs or request features](https://github.com/csprance/gecs/issues)

**Full Changelog**: [v4.x...v5.0.0](https://github.com/csprance/gecs/compare/v4.0.0...v5.0.0)

---

## [3.8.0] - 2024-XX-XX - Performance Boost & Documentation Overhaul

## 🎯 Major Improvements

### ⚡ Performance Optimizations

- **1.58x Query Performance Boost** - Implemented QueryBuilder pooling and world-level query caching
- **Fixed Component Replacement Bug** - Entities no longer processed twice when components are replaced
- **Array Operations Performance Revolution** - 4.6x faster intersection, 2.6x faster difference, 1.8x faster union operations
- **Memory Leak Prevention** - Better resource management and cleanup

### 📚 Complete Documentation Restructure

- **User-Friendly Learning Path** - Progressive guides from 5-minute tutorial to advanced optimization
- **Comprehensive Guides** - New Getting Started, Best Practices, Performance, and Troubleshooting guides
- **Addon-Centric Documentation** - All docs now ship with the addon for better distribution
- **Consistent Naming Conventions** - Standardized C*, s*, e*, o* prefixes throughout
- **Community Integration** - Discord links throughout for support

### 🧪 Enhanced Testing Framework

- **Performance Test Suite** - Comprehensive benchmarking for all ECS operations
- **Regression Detection** - Automated performance threshold monitoring
- **Better Test Organization** - Restructured tests into logical groups (core/, performance/)

## 🔧 Technical Changes

### Core Framework

- **QueryBuilder Pooling** - Reduced object creation overhead
- **World-Level Query Caching** - Hash-based caching with automatic invalidation
- **Component Replacement Fix** - Proper removal before replacement in entity.gd:97-111
- **Array Performance Revolution** - Algorithmic improvements from O(n²) to O(n) complexity using dictionary lookups

### Documentation Structure

- **Root README.md** - Clean overview pointing to addon documentation
- **addons/gecs/README.md** - Complete documentation index for distribution
- **addons/gecs/docs/** - All user guides properly organized
- **Progressive Learning Path** - 5min → 20min → 60min guide progression

### Testing & Quality

- **Performance Baselines** - Established benchmarks for regression detection
- **Comprehensive Coverage** - Entity, Component, Query, System, and Integration tests
- **Cross-Platform Compatibility** - Improved test reliability

## 📈 Performance Metrics

### Array Operations Benchmarks

- **Intersection Operations**: 4.6x faster (0.888ms → 0.194ms)
- **Difference Operations**: 2.6x faster (0.361ms → 0.141ms)
- **Union Operations**: 1.8x faster (0.372ms → 0.209ms)
- **No Overlap Scenarios**: 4.2x faster (0.629ms → 0.149ms)

### Algorithmic Improvements

- **O(n²) → O(n) Complexity**: Replaced Array.has() with Dictionary lookups
- **Smart Size Optimization**: Intersect operations use smaller array for lookup table
- **Uniqueness Tracking**: Union operations prevent duplicates with dictionary-based deduplication
- **Consistent Optimization Pattern**: All array operations use same high-performance approach

### Framework Performance

- **Query Caching**: 1.58x speedup for repeated queries
- **Component Operations**: Reduced double-processing bugs
- **Memory Usage**: Better cleanup and resource management
- **Test Suite**: Comprehensive benchmarking with automatic thresholds

## 🎮 For Game Developers

- **Dramatically Faster Games** - Up to 4.6x performance improvement in entity filtering and complex queries
- **Better Documentation** - Clear learning path from beginner to advanced
- **Consistent Patterns** - Standardized naming and organization conventions
- **Community Support** - Discord integration for help and discussions

## 🔄 Migration Notes

This is a **backward-compatible** update. No breaking changes to the API.

- Existing projects will automatically benefit from performance improvements
- Documentation has been reorganized but all links remain functional
- Test structure improved but does not affect game development

## 🌟 Community

- **Discord**: [Join our community](https://discord.gg/eB43XU2tmn)
- **Documentation**: [Complete guides](addons/gecs/README.md)
- **Issues**: [Report bugs or request features](https://github.com/csprance/gecs/issues)

---

**Full Changelog**: [v3.7.0...v3.8.0](https://github.com/csprance/gecs/compare/v3.7.0...v3.8.0)

The v3.8.0 version reflects a significant minor release with substantial improvements to performance, documentation, and testing while maintaining full backward compatibility with the existing v3.x API.
