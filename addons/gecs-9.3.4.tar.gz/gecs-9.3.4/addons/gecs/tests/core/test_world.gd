extends GdUnitTestSuite

# Assuming GutTest is the correct base class in your setup

var runner: GdUnitSceneRunner
var world: World


func before():
	runner = scene_runner("res://addons/gecs/tests/test_scene.tscn")
	world = runner.get_property("world")
	ECS.world = world


func after_test():
	if world:
		world.purge(false)


func test_add_and_remove_entity():
	var entity = Entity.new()
	# Test adding
	world.add_entities([entity])
	assert_bool(world.entities.has(entity)).is_true()
	# Test removing
	world.remove_entity(entity)
	assert_bool(world.entities.has(entity)).is_false()


func test_add_and_remove_system():
	var system = System.new()
	# Test adding
	world.add_systems([system])
	assert_bool(world.systems.has(system)).is_true()
	# Test removing
	world.remove_system(system)
	assert_bool(world.systems.has(system)).is_false()


func test_add_entity_twice_is_noop():
	var entity = Entity.new()
	world.add_entity(entity)
	world.add_entity(entity)
	assert_int(world.entities.count(entity)).is_equal(1)


func test_add_disabled_entity_again_is_noop():
	var entity = Entity.new()
	world.add_entity(entity)
	world.disable_entity(entity)
	# Disabled entities stay in the entities array with _world nulled; a re-add
	# must not double them.
	world.add_entity(entity)
	assert_int(world.entities.count(entity)).is_equal(1)
	assert_bool(entity.enabled).is_false()


func test_add_system_twice_is_noop():
	var system = System.new()
	world.add_system(system)
	world.add_system(system)
	assert_int(world.systems.count(system)).is_equal(1)


func test_add_system_calls_setup():
	var system = SetupTestSystem.new()
	assert_bool(system.setup_was_called).is_false()

	world.add_system(system)

	assert_bool(system.setup_was_called).is_true()
	assert_bool(world.systems.has(system)).is_true()


func test_purge():
	# Add an entity and a system
	var entity1 = Entity.new()
	var entity2 = Entity.new()
	world.add_entities([entity2, entity1])

	var system1 = System.new()
	var system2 = System.new()
	world.add_systems([system1, system2])

	# PURGE!!!
	world.purge(false)
	# Should be no entities and systems now
	assert_int(world.entities.size()).is_equal(0)
	assert_int(world.systems.size()).is_equal(0)
